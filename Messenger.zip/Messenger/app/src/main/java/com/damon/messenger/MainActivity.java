package com.damon.messenger;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    //crear un obejo de tipo toolbar que es la parte de arriba de toda aplicaicon
    private Toolbar mToolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mToolbar = findViewById(R.id.main_page_toolbar);//inicializamos el toolbar
        setSupportActionBar(mToolbar);//añadimos el toolbar
        getSupportActionBar().setTitle("Messenger");//añadimos el titulo

    }
}
